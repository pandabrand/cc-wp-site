<?php

if( !function_exists('pmai_join_attr') ):
	function pmai_join_attr( $attributes = false ){
		echo pmai_get_join_attr( $attributes );
	}
endif;

?>